from setuptools import setup

setup(
    name='csgo_config_parser',
    version= '0.0.1',
    author= 'Ananthu Saseendran',
    description='A simple parse module to parse csgo congfig and video settings',
    packages=['csgo_config_parser']
)
