# csgo_config_parser
A parser for csgo config and video settings
